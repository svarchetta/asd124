package server;

import java.rmi.RemoteException;

import client.GameClient;

import java.rmi.Remote;



public interface GameServer extends Remote{
	public void iscrivi(GameClient client)throws RemoteException;

}
