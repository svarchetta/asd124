package server;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.sun.tools.javac.code.Type.ForAll;

import client.GameClient;






public class GameServerImpl extends UnicastRemoteObject implements GameServer{
	
	/*aggiunta seriale*/
	private static final long serialVersionUID = 1L;
	
	/*dichiarazione e creazione del logger*/
	static Logger logger=Logger.getLogger("global");
	
	/*aggiunto private a variablile partecipanti*/
	private static ArrayList<GameClient> partecipanti = new ArrayList<GameClient>();
	
	public  GameServerImpl() throws RemoteException {}
	
	public static  void main(String args[]) {
		/* aggiunta controllo del Security manager
		 * con conseguente istanziazione */
		if(System.getSecurityManager()==null)
			System.setSecurityManager(new SecurityManager());
		/* 
		 * aggiunta blocco try catch ponendo 
		 * all'interno del blocco try istaziazione di serever
		 * e registrazione di server sul registry
		 * al di nel catch cattura delle eccezioni
		 * */
		try {
			/*aggiunta di tutte le stampe di
			 * controllo relative per all' istazaione 
			 * e registrazione del server */
			logger.info("Istaziazione del Server..");
			GameServerImpl server=new GameServerImpl();
			logger.info("Registrazione sul servizio di naming...");
			Naming.rebind("GameServer", server);
			logger.info("Server Pronto...");
		} catch (RemoteException e) {
			logger.info("Problemi con ogetti remoti.");
			e.printStackTrace();
		}catch (Exception e) {
			logger.info("Altri Problemi.");
			e.printStackTrace();
		}
	}
	
	public void iscrivi(GameClient rif)throws RemoteException{
		if(partecipanti.size()<2) {
			
		    if (partecipanti.size()==0) {
		    	partecipanti.add(rif);
				rif.scrivi("Hi " + rif.getNickname() + " you are the first participant "
						+ "so you have to wait the scond one to start");
				String disc = rif.scriviRicevi("which disc do you choose red or yellow one?"
						+ "\nPlease Insert (R) for the red one (Y) for the yellow one.");
				while (!disc.equals("R") && !disc.equals("Y")) {
					disc = rif.scriviRicevi("You did not enter R or Y as suggested, enter one of the two. Please.");
				}
				rif.scrivi("Your choice is: " + disc);
				rif.setDisc(disc);
			}else if (partecipanti.size()==1){
				partecipanti.add(rif);
				startGame(rif);
				
			}
		}
		else{
		    rif.scrivi("Hi .the number of participants is already 2 therefore you cannot participate in the game for now. Sorry."); 
			rif.setOff();	
		}
		//startGame(rif);
	}

	private synchronized void startGame(GameClient rif) throws RemoteException {
		if(partecipanti.size()==2){
			String firstDisc = partecipanti.get(0).getDisc();
			if(firstDisc.equals("Y")) {
			  rif.scrivi("Hi "+rif.getNickname()+"! You are the second palyer"+
			  "\nthe yellow disk has already been chosen and the red is assigned to you");
			  rif.setDisc("R");
			}
			else {
		       rif.scrivi("Hi "+rif.getNickname()+"! You are the second palyer"+
						  "\nthe red disk has already been chosen and the yellow is assigned to you");
		       rif.setDisc("Y");
		    }
			boolean loop = true;	
			String [][]pattern=createPattern();
			for (int i = 0; i < partecipanti.size(); i++) {
				partecipanti.get(i).printPattern(pattern);
				partecipanti.get(i).scrivi("The game start");
			} 
			int count = 0;
			GameClient partFirst=partecipanti.get(0);
			GameClient partSecond=partecipanti.get(1);
			while (loop) {
				 if (count % 2 == 0) { 
					 partFirst.scrivi("it's your turn "+partFirst.getNickname());
					 partSecond.scrivi("it's the turn of "+partFirst.getNickname());
					 if(partFirst.getDisc().equals("R")) {
						 dropForRed(pattern, partFirst, partSecond);
					 }
					 else if(partFirst.getDisc().equals("Y")) {
						 dropForYellow(pattern, partFirst, partSecond);
					 }
				 }else {
					 partSecond.scrivi("it's your turn "+partSecond.getNickname());
					 partFirst.scrivi("it's the turn of "+partSecond.getNickname());
					 if(partSecond.getDisc().equals("R")) {
						 dropForRed(pattern, partSecond, partFirst);
					 }
					 else if(partSecond.getDisc().equals("Y")) {
						 dropForYellow(pattern, partSecond, partFirst);
					 }
					 
				 }
				 if(checkWinner(pattern)!=null) {
					 if (checkWinner(pattern) == "R") {
						 if(partFirst.getDisc().equals("R")) {
						      partFirst.scrivi("Congratulation "+partFirst.getNickname()+" you win!!!");
						      partSecond.scrivi("Sorry "+partSecond.getNickname()+" you loose. "+partFirst.getNickname()+" wins");
					     }else if(partSecond.getDisc().equals("R")){
					    	 partSecond.scrivi("Congratulation "+partSecond.getNickname()+" you win");
					    	 partFirst.scrivi("Sorry "+partFirst.getNickname()+" you loose. "+partSecond.getNickname()+" wins");
					     }
						 
					 }else if(checkWinner(pattern) == "Y") {
						 if(partFirst.getDisc().equals("Y")) {
						      partFirst.scrivi("Congratulation "+partFirst.getNickname()+" you win!!!");
						      partSecond.scrivi("Sorry "+partSecond.getNickname()+" you loose. "+partFirst.getNickname()+" wins");
					     }else if(partSecond.getDisc().equals("Y")){
					    	 partSecond.scrivi("Congratulation "+partSecond.getNickname()+" you win");
					    	 partFirst.scrivi("Sorry "+partFirst.getNickname()+" you loose. "+partSecond.getNickname()+" wins");
					     }

					 }
					 
					 loop=false;
					 GameClient tmp=null;
					 while(!partecipanti.isEmpty()){
						 try{
								tmp=partecipanti.remove(0);
								tmp.setOff();
							}catch(RemoteException e){
								;
							}
					 }
						
					 
				 }
				 count++;
			}
			
		}
	}

	private void dropForYellow(String[][] pattern, GameClient partFirst, GameClient partSecond) throws RemoteException {
		String recieve=partFirst.scriviRicevi("Drop a yellow disk at column (0�9): or Esc to exit");
		if(recieve.equals("Esc")) {
			partFirst.scrivi(partFirst.getNickname()+" hai deciso di usire!");
			partSecond.scrivi(partFirst.getNickname()+" ha deciso di uscire. Il gioco � finito");
			GameClient tmp=null;
			while(!partecipanti.isEmpty()){
				 try{
						tmp=partecipanti.remove(0);
						tmp.setOff();
					}catch(RemoteException e){
						;
					}
			 }
		}else {
			
		 int n=Integer.parseInt(recieve);
		 int c=2*n+1;
		 dropYellowPattern(pattern, c);
		 partFirst.printPattern(pattern);
		 partSecond.printPattern(pattern);
		}
	}

	private void dropForRed(String[][] pattern, GameClient partFirst, GameClient partSecond) throws RemoteException {
		String recieve=partFirst.scriviRicevi("Drop a red disk at column (0�9): or Esc to exit");
		if(recieve.equals("Esc")) {
			partFirst.scrivi(partFirst.getNickname()+" hai deciso di usire!");
			partSecond.scrivi(partFirst.getNickname()+" ha deciso di uscire. Il gioco � finito");
			GameClient tmp=null;
			while(!partecipanti.isEmpty()){
				 try{
						tmp=partecipanti.remove(0);
						tmp.setOff();
					}catch(RemoteException e){
						;
					}
			 }
		}else {
			
		 int n=Integer.parseInt(recieve);
		 int c=2*n+1;
		 dropRedPattern(pattern, c);
		 partFirst.printPattern(pattern);
		 partSecond.printPattern(pattern);
		}
	}
	
	
	  
	
	  private static String checkWinner(String[][] f){
	
	     
	
	
	    for (int i =0;i<6;i++){
	
	      
	
	      for (int j=0;j<10;j+=2){
	
	        if (((f[i][j+1] != " ")
	        && (f[i][j+3] != " ")
	        && (f[i][j+5] != " ")
	        && (f[i][j+7] != " ")
	        && (f[i][j+9] != " ")
	
	        && ((f[i][j+1] == f[i][j+3])
	
	        && (f[i][j+3] == f[i][j+5])
	
	        && (f[i][j+5] == f[i][j+7])
	        
	        && (f[i][j+7] == f[i][j+9])))
	        ||
	        ((f[i][j+3] != " ")
			&& (f[i][j+5] != " ")
			&& (f[i][j+7] != " ")
			&& (f[i][j+9] != " ")
			&& (f[i][j+11] != " ")
			            && ((f[i][j+3] == f[i][j+5])
						
				        && (f[i][j+5] == f[i][j+7])
				
				        && (f[i][j+7] == f[i][j+9])
				        
				        && (f[i][j+9] == f[i][j+11])))){
	
	
	
	       
	          //System.out.println("Determinato dal controllo 1 si basa sulle righe");
	          return f[i][j+1]; 
	        }
	
	      }
	
	    }
	
	     
	
	
	    for (int i=1;i<21;i+=2){
	
	      
	
	      for (int j =0;j<3;j++){
	
	            if((f[j][i] != " ")
	
	            && (f[j+1][i] != " ")
	
	            && (f[j+2][i] != " ")
	
	            && (f[j+3][i] != " ")
	            
	            && (f[j+4][i] != " ")
	
	            && ((f[j][i] == f[j+1][i])
	
	            && (f[j+1][i] == f[j+2][i])
	
	            && (f[j+2][i] == f[j+3][i])
	            
	            && (f[j+3][i] == f[j+4][i])
	            
	            )) {
	              //System.out.println("Determinato dal controllo 2 ovvero quello delle colonne");	
	              return f[j][i]; 
	            }
	
	      } 
	
	    }
	
	     
	
	
	    for (int i=0;i<2;i++){
	
	    	 for (int j=1;j<12;j+=2){
	
		            if((f[i][j] != " ")
	
		            && (f[i+1][j+2] != " ")
	
		            && (f[i+2][j+4] != " ")
	
		            && (f[i+3][j+6] != " ")
		            
		            && (f[i+4][j+8] != " ")
	
		            && ((f[i][j] == f[i+1][j+2])
	
		            && (f[i+1][j+2] == f[i+2][j+4])
	
		            && (f[i+2][j+4] == f[i+3][j+6])
		            
		            && (f[i+3][j+6] == f[i+4][j+8]))) {
		             //System.out.println("Determinato dal controllo 3 diagonale da sinistra alta a destra bassa");	
		              return f[i][j]; 
		            }
	
		      } 
	
	    }
	
	    for (int i=0;i<2;i++)
	
	    {
	
	      for (int j=7;j<21;j+=2)
	
	      {
	
	            if((f[i][j] != " ")
	
	            && (f[i+1][j-2] != " ")
	
	            && (f[i+2][j-4] != " ")
	
	            && (f[i+3][j-6] != " ")
	            
	            && (f[i+4][j-8] != " ")
	
	            && ((f[i][j] == f[i+1][j-2])
	
	            && (f[i+1][j-2] == f[i+2][j-4])
	
	            && (f[i+2][j-4] == f[i+3][j-6])
	            && (f[i+3][j-6] == f[i+4][j-8])
	            )) {
	              //System.out.println("Determinato dal controllo 4 diagonale da destra alta sinsitra bassa");	
	              return f[i][j]; 
	            }
	
	      } 
	
	    }
	
	     
	
	
	    return null;
	
	  }

	private static void dropRedPattern(String[][] f,int c){
	
	    //System.out.println("Drop a red disk at column (0�9): ");
	    //int c = 2*scan.nextInt()+1;
	
	    for (int i =5;i>=0;i--){
	
	      if (f[i][c] == " "){
	           f[i][c] = "R";
	           break;
	      }
	    }
	
	  }

	private static void dropYellowPattern(String[][] f,int c){
	
	    //System.out.println("Drop a yellow disk at column (0�9): ");
	    // int c = 2*scan.nextInt()+1;
	
	    for (int i =5;i>=0;i--){
	
	      if (f[i][c] == " "){
	    	  f[i][c] = "Y";
	    	  break;
	      }
	    }
	
	  }

	private static String[][] createPattern() {
	
	    
	
	     String[][] f = new String[7][21];
	
	     for (int i =0;i<f.length;i++){
	
	       
	
	      
	      
	       for (int j =0;j<f[i].length;j++){
	
	        if (j% 2 == 0 ) {
	        	f[i][j] ="|";
	        	
	        }
	      
	        else f[i][j] = " ";
	
	        if (i==6) f[i][j]= "-";
	
	      }
	
	       
	
	    }
	
	    return f;
	
	  }
}
