package client;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GameClient extends Remote {
	public void printPattern(String[][] f)throws RemoteException;
	public void scrivi(String s)throws RemoteException;
	public String getNickname()throws RemoteException;
	public void setDisc(String s)throws RemoteException;
	public String getDisc()throws RemoteException;
	public String scriviRicevi (String s) throws RemoteException;
	public  void setOff()throws RemoteException;
	//public void dropPattern()throws RemoteException;
	
}
