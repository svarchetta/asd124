package client;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;
import java.util.logging.Logger;

import server.GameServer;







public class GameClientImpl extends UnicastRemoteObject implements GameClient{
	
	/* aggiunto seriale */
	private static final long serialVersionUID = 1L;
	
	/* dichiarazione e creazione del logger */
	static Logger logger=Logger.getLogger("global");

	public GameClientImpl()throws RemoteException {}
	
	private  static String nickname="";
	
	private String disc;
	
	private static Scanner scan;
	

	
	
	
public static void main(String args[]){
		
		/* aggiunta controllo del Security manager
		 * con conseguente istanziazione */
		//if(System.getSecurityManager()==null)
			//System.setSecurityManager(new SecurityManager());
		
		
		/* sottomissione di tutte le
		 * istruzioni che seguono all'interno del 
		 * blocco try e conseguente cattura
		 * delle eccezioni nel blocco catch
		 * */
		try {
			/* aggiunta di tutte le stampe
			 * di conrollo per trovare il server
			 * iscrivere il client 
			 * al server*/
			
			logger.info("Ricerca del server...");
			/* aggiunta del cast(ChatClapServer) */
			GameServer server=(GameServer)Naming.lookup("rmi://localhost/GameServer");
			logger.info("Server trovato!");
			scan=new Scanner(System.in);
			
			System.out.println("Please Insert your name:");
			nickname=scan.nextLine();
			
			GameClient client =new GameClientImpl();
			server.iscrivi(client);
			
			while(true) {
			
			}
			
			
			
			
			
			
		
		}catch (RemoteException e) {
			logger.info("Problemi con ogetti remoti.");
			e.printStackTrace();
		}catch (Exception e) {
			logger.info("Altri Problemi.");
			e.printStackTrace();
		}
	}

	public  void printPattern(String[][] f)throws RemoteException{
	   for (int i =0;i<f.length;i++){
		   for (int j=0;j<f[i].length;j++){
	    	  System.out.print(f[i][j]);
		   }
		   System.out.println();
	   }
	}
	
	public void scrivi (String s)throws RemoteException {
		System.out.println(s);
	}
	
	public String scriviRicevi (String s) throws RemoteException{
		System.out.println(s);
		String toReturn=scan.nextLine();
		return toReturn;
	}
	
	public String getNickname()throws RemoteException {
		return nickname;
	}
	
	public void setDisc(String s)throws RemoteException{
		this.disc=s;
	}
	
	public String getDisc()throws RemoteException{
		return disc;
	}

	public void setOff()throws RemoteException{
	     System.exit(0);
	}

	
}
